-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 19, 2023 at 02:35 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `account_info`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `id` int(11) NOT NULL,
  `Fullname` varchar(155) NOT NULL,
  `Username` varchar(155) NOT NULL,
  `Email` varchar(155) NOT NULL,
  `Phone_Num` varchar(155) NOT NULL,
  `Gender` varchar(155) NOT NULL,
  `Password` varchar(155) NOT NULL,
  `user_type` varchar(155) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`id`, `Fullname`, `Username`, `Email`, `Phone_Num`, `Gender`, `Password`, `user_type`) VALUES
(1, 'Renan Boniza', 'Renan', 'RenanBoniza@gmail.com', '09123456789', 'Male', '123', 'admin'),
(2, 'Janver Deleon', 'Janver', 'JanverDeleon', '09123456789', 'Male', '234', 'staff'),
(3, 'John Joseph Pantaleon', 'Joseph', 'JohnJosephPantaleon@gmail.com', '09123456789', 'Male', '098', 'client');

-- --------------------------------------------------------

--
-- Table structure for table `truck`
--

CREATE TABLE `truck` (
  `Truck_Id` int(11) NOT NULL,
  `Truck_PlateNumber` varchar(155) NOT NULL,
  `Truck_Type` varchar(155) NOT NULL,
  `Truck_Space` varchar(155) NOT NULL,
  `Status` varchar(155) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `truck`
--

INSERT INTO `truck` (`Truck_Id`, `Truck_PlateNumber`, `Truck_Type`, `Truck_Space`, `Status`) VALUES
(1, 'ABC123', '10 Wheeler', '20', 'Available');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `truck`
--
ALTER TABLE `truck`
  ADD PRIMARY KEY (`Truck_Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `truck`
--
ALTER TABLE `truck`
  MODIFY `Truck_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
